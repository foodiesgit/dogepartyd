
class ScriptError(Exception): pass
